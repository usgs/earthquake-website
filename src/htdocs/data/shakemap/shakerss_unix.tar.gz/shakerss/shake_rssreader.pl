#! /usr/bin/perl

####################################
# shake_rssreader.pl
# version 0.4.6  kl 11/21/2006
#   Added download options for event time window and magnitude cutoff.
# version 0.4.5  kl 10/12/2006
#   Correct download flag error after creating directory
# version 0.4.3  kl 03/08/2006
#   Added proxy configuration
# version 0.4.2  kl 02/20/2006
#   Update logmsg for postcmd runs
# version 0.4.1  kl 02/15/2006
#   Added <SHAKE_WEB> option for launching browser with ShakeMap
# version 0.4  kl 02/07/2006
#   Added region code download option
#   Updated RSS url and parsing for new USGS web
#   Bug fixes on retrieving and saving data files
# version 0.3  kl 12/02/2005
#   Added shakemap-like command line parameters and a config file for 
#     storing download options, loggings, and post-command executions.
# version 0.2
#
# Kuo-wan Lin, klin@usgs.gov
# 
# checks the rss feed at http://earthquake.usgs.gov/eqcenter/shakemap/shakerss.php 
# for new events and executes command (above) for each new shakemap product file
#
# creates a file, shake.dat, to store the most recent timestamp, 
# and a folder, grds, to store all downloaded grd files
#
####################################


####################################
#to install LWP::Simple (simple HTTP get requests)
# as root or sudo
#	perl -MCPAN -e 'install LWP::Simple'
#
#the alternative without LWP::Simple  kl 12/08/2005
# just put the script "SimpleGet.pl" in the same
#   directory as the RSS reader
####################################
	

use strict;

use FindBin;
use lib $FindBin::Bin;
#use LWP::Simple;
require "SimpleGet.pl";
use File::Basename;
use File::Path;
use IO::File;
use Getopt::Long;
use Carp;
use Time::Local;

############################################################################
# Prototypes for the logging routines
############################################################################
sub logmsg;
sub logver;
sub logerr;
sub logscr;
sub mydate;

#######################################################################
# Stuff to handle command line options and program documentation:
#######################################################################

my $desc = "Check the RSS feed at http://earthquake.usgs.gov/eqcenter/shakemap/shakerss.php "
	 . "for new events and execuates command for retrieved data files. ";

my $flgs = [{ FLAG => 'event',
              ARG  => 'event_id',
              DESC => 'Specifies the id of the event to process'},
            { FLAG => 'config_check',
			  DESC => 'Check the configuration file, then quit.'},
            { FLAG => 'help',
              DESC => 'Print program documentation and quit.'},
            { FLAG => 'verbose',
              DESC => 'Print detailed processing information.'}
           ];

my $options = setOptions($flgs) or die "Error in setOptions";

if (defined $options->{'help'}) {
  printDoc($desc);
  exit 0;
}

my $evid    = $options->{'event'} if defined $options->{'event'};
my $config_quit  = defined $options->{'config_check'} ? 1 : 0;
my $verbose = defined $options->{'verbose'} ? 1 : 0;

logscr "Unknown argument(s): @ARGV" if (@ARGV);


#######################################################################
# User config 
#######################################################################
	
my $logfile;			# Where we dump all of our messages
my $log;			# Filehandle of the log file
my $rss_home = $FindBin::Bin;
my $cfile      = "shake_rssreader.conf";
my $config_dirs = [ $rss_home ];
my @postcmds;				# list of commands from the 'postcmd' config statement
my $download_dir;
my $rss_url;
my @data_files;
my @events;
my @regions;
my $all_regions;
my $time_window = 0;
my $mag_cutoff = 0;

#
# Parse the config file
#
configure($cfile);
if ($config_quit) {
	logscr "Config succeeded, quitting.";
    exit 0;
}
@events = () unless (defined $options->{'event'});

#######################################################################
# End of command line option stuff
#######################################################################

#######################################################################
# Run the program
#######################################################################


main();

#######################################################################
# Subroutines
#######################################################################

sub main {


#set last time RSS read
	my $min_shake_time = 0;
	if( -e "$rss_home/shake_rssreader.dat" )
	{
		open(SHAKE, "<$rss_home/shake_rssreader.dat");
		$min_shake_time = <SHAKE>;
		$min_shake_time = time() - $time_window * 86400 
		  if (! defined $min_shake_time);
		close(SHAKE);
	}

#get current rss
	logmsg "Retrieving Shake RSS Data";

	my $rss_data = get($rss_url);
	logscr "\nReturn: ",substr($rss_data,0, 80),"...\n" if ($verbose);
	my @items = rss_to_items($rss_data);
	logmsg "\t$#items RSS items in feed";

#track new min_shake_time and number of new events
	my $max_time = $min_shake_time;
	my $num_new = 0;


#execute command for each new item
	foreach my $item (@items) {
	  my $region_code = &region_code($item);
	  next unless ((grep /$region_code/i, @regions) || $all_regions);
	  if (defined $evid) {
	    if (item_grid($item) =~ /\/$evid\//) {
		@events = ($item);
		last;
		}
	  } else {
		my $time_cutoff = item_eq_time($item) + $time_window * 86400;
	    my $time = item_time($item);
	    my $mag = item_mag($item);
	    $max_time = $time if($time > $max_time);
	    if($time > $min_shake_time && $time < $time_cutoff 
		  && $mag > $mag_cutoff) {
		  ++$num_new;
		  push @events, $item;
	    }
	  }
	}

	foreach(@events) {
	  #get grid url
	  my $grid = item_grid($_);
	  my $link = item_link($_);
	   

	  #get event id
	  $grid =~ /shake\/(.+)\/download/;
	  $evid = $1;

	  #get network id
	  $grid =~ /shakemap\/(.+)\/shake/;
	  my $network = $1;
	  my $failed_dn = 'false';
	  foreach my $data_file (@data_files) {
	    #download grid file
		my $grid_url = "$grid/$data_file";
		$grid_url =~ s/<EVENT>/$evid/g;
		my $grid_contents = get($grid_url);

	    if (not defined $grid_contents) {
		  $data_file .= ".zip";
		  $grid_contents = get($grid_url);
		}

	    if (defined $grid_contents) {
	      logmsg "Download: Event $grid_url File";
	    } else {
		  $data_file =~ s/.zip$//;
	      logmsg "Download Failed: Event $grid_url File";
		  $failed_dn = 'true';
	      next;
	    };
		
	    #validate directory
        my $dest = $download_dir."/$evid";
	    if (not -e "$dest") {
	      my $result = mkpath("$dest", 0, 0755);
		  if (!$result) {
		  logmsg "Couldn't create download dir $dest";
		  $failed_dn = 'true';
		  }
	    }

	    #save grid file
		my $saved_file = "$dest/$data_file";
		$saved_file =~ s/<EVENT>/$evid/g;
	    open(GRD, ">$saved_file")  or logmsg "Couldn't save file: $saved_file";
	    binmode GRD;
	    print GRD $grid_contents;
	    close(GRD);
		# Stupid Windows fix for .zip type masking
		if (-B "$dest/$data_file" && "$dest/$data_file" =~ /.ps$|.txt$|.xyz$/) {
		  rename("$dest/$data_file", "$dest/$data_file.zip");
		}
	  }

	  #postcmd runs
	  if (@postcmds && @events && $failed_dn eq 'false') {
        foreach ( @postcmds ) {
		  my $cmd = $_;
		  $cmd =~ s/<EVENT>/$evid/g;
		  $cmd =~ s/<SHAKE_WEB>/$link/g;
		  #print "Running command: $cmd\n";
		  my $rc = system($cmd);
	      if ($rc == 0) {
		    logmsg "Normal command run: '$cmd'";
          } else {
			logmsg "Error command run: $rc, '$cmd'";
		  }
        }
      }
	
	}

#store time of last shakemap in shake.dat
	open(SHAKE, ">$rss_home/shake_rssreader.dat");
	print SHAKE $max_time;
	close(SHAKE);

return 0;
}

#split rss feed into array of items, item data is untampered, but item tags do not match (cant use with XML::Simple)
sub rss_to_items
{
	my $rss = shift;

	my ($start, @items) = split '<item>', $rss;

	foreach(@items)
	{
		s/<\/item>.+//;
	}

	return(@items);
}

#parses creation time of an RSS item
sub item_mag
{
	my $item = shift;
	
	$item =~ /<title>([\d\.]+)\s*\-.+<\/title>/;

	return($1);
}

sub item_time
{
	my $item = shift;
	
	$item =~ /<eq:seconds>(\d+)<\/eq:seconds>/;

	return($1);
}

sub item_eq_time
{
	my $item = shift;
	my %month = ( "JAN" => 0,
					"FEB" => 1,
					"MAR" => 2,
					"APR" => 3,
					"MAY" => 4,
					"JUN" => 5,
					"JUL" => 6,
					"AUG" => 7,
					"SEP" => 8,
					"OCT" => 9,
					"NOV" => 10,
					"DEC" => 11 );
					
	#<pubDate>Tue, 21 Nov 2006 21:06:23 +0000</pubDate>
	my ($day, $mon, $year, $hour, $min, $sec) = $item =~
	  /<pubDate>.+\s(\d+)\s(\w+)\s(\d+)\s(\d+):(\d+):(\d+).+<\/pubDate>/;
	
	#print "($day, ",$month{uc($mon)},", $year, $hour, $min, $sec)\n";
	return (timegm($sec, $min, $hour, $day, $month{uc($mon)}, $year-1900));
}

sub region_code
{
	my $item = shift;
	
	$item =~ /<eq:region>(\w+)<\/eq:region>/;

	return($1);
}

#parses link and appends grid file to path
sub item_grid
{
	my $item = shift;

	my ($url) = $item =~ /<link>(.+)<\/link>/;
#	$url =~ s/intensity.html$/download\//i;
	$url =~ s/(index.php|intensity.html)$//i;
	
#	return($1 . "/grid.xyz");
	$url .= 'download/';
	return($url);
}

#parses link and appends grid file to path
sub item_link
{
	my $item = shift;

	my ($url) = $item =~ /<link>(.+)<\/link>/;

	return($url);
}

my $fref;
my ($bn, $flag, $type, $flag_desc, $pdoc);
sub setOptions {
  $fref     = shift;
  my $dbug  = shift;
  my @names = ();

  foreach my $ff ( @$fref ) {
    (defined $ff->{FLAG} and $ff->{FLAG} !~ /^$/) or next;
    my $str = $ff->{FLAG};
    #----------------------------------------------------------------------
    # Is there an argument?
    #----------------------------------------------------------------------
    if ((defined $ff->{ARG}  and $ff->{ARG}  !~ /^$/)
     or (defined $ff->{TYPE} and $ff->{TYPE} !~ /^$/)
     or (defined $ff->{REQ}  and $ff->{REQ}  !~ /^$/)) {
      #----------------------------------------------------------------------
      # Yes, there's an argument of some kind; is it 
      # manditory or optional?
      #----------------------------------------------------------------------
      $str .= (defined $ff->{REQ} and $ff->{REQ} =~ /y/) ? '=' : ':';
      #----------------------------------------------------------------------
      # What is the expected type of the argument; default to 's'
      #----------------------------------------------------------------------
      my $type = (defined $ff->{TYPE} and $ff->{TYPE} !~ /^$/) 
               ? $ff->{TYPE} : 's';
      $str .= $type;
      #----------------------------------------------------------------------
      # If the type of argument is '!', then set $str directly
      #----------------------------------------------------------------------
      if ($type eq '!') {
	$str = $ff->{FLAG} . $type;
      }
      #----------------------------------------------------------------------
      # If ARG is undefined or empty, fix it up for the documentation
      #----------------------------------------------------------------------
      if (!defined $ff->{ARG} or $ff->{ARG} =~ /^$/) {
	$ff->{ARG} = $type =~ /s/ ? 'string'
		   : $type =~ /i/ ? 'integer'
		   : $type =~ /f/ ? 'float'
		   : $type =~ /!/ ? ''
		   : '???';
	if (defined $ff->{REQ}  and $ff->{REQ}  !~ /y/) {
	  $ff->{ARG} = '[' . $ff->{ARG} . ']';
	}
      }
    }
    print "OPTION LINE: $str\n" if (defined $dbug and $dbug != 0);
    push @names, $str;
  }

  my $options = {};

  if (@names) {
    GetOptions($options, @names) or die "Error in GetOptions";
  }

  if (defined $dbug and $dbug != 0) {
    foreach my $key ( keys %$options ) {
      print "option: $key value: $options->{$key}\n";
    }
  }
  return $options;
}

sub printDoc {

  $pdoc = shift;
  $bn   = basename($0);

  $~ = "PROGINFO";
  write;

  if (@$fref) {
    $~ = "OPTINFO";
  } else {
    $~ = "NOOPTINFO";
  }
  write;

  $~ = "FLAGINFO";
  foreach my $ff ( @$fref ) {
    (defined $ff->{FLAG} and $ff->{FLAG} !~ /^$/) or next;
    $flag      = $ff->{FLAG};
    $type      = defined $ff->{ARG}  ? $ff->{ARG}  : '';
    $flag_desc = defined $ff->{DESC} ? $ff->{DESC} : '';
    write;
  }
  $~ = "ENDINFO";
  write;
  0;
}

#######################################################################
# Self-documentation formats; we use the '#' character as the first 
# character (which is a royal pain to do) so that the documentation 
# can be included in a shell file
#######################################################################

format PROGINFO =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
'################################################################################'
@ Program     : @<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
'#',	 $bn
^ Description : ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
rhsh($pdoc),	      $pdoc
^ ~~            ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
rhsh($pdoc),	      $pdoc
@ Options     :
'#'
.

format OPTINFO =
@     Flag       Arg       Description
'#'
.

format NOOPTINFO =
@     NONE
'#'
.

format FLAGINFO =
@     ---------- --------- -----------------------------------------------------
'#'
^    -@<<<<<<<<< @<<<<<<<< ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
rhsh($flag_desc), $flag, $type, $flag_desc
^ ~~                       ^<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
rhsh($flag_desc),	   $flag_desc
.

format ENDINFO =
@<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
'################################################################################'
.

sub rhsh {

  my $more = shift;
  return '#' if ($more ne '');
  return '';
}


############################################################################
# Logs a message to the logfile with time/date stamp
############################################################################
sub logmsg { 

  print $log "$$: @_ on ", mydate(), "\n";
  print "@_ on ", mydate(), "\n";
  return;
}

############################################################################
# Logs a message to the logfile without time/date stamp
############################################################################
sub logver { 

  print $log "$$: @_\n";
  return;
}

############################################################################
# Logs a message with time/date stamp to the logfile, then quits
############################################################################
sub logerr { 

  logmsg shift; 
  exit 1; 
}

############################################################################
# Logs a message with to the screen
############################################################################
sub logscr { 

  print STDOUT "$0 $$: @_ on ", mydate(), "\n";
  return;
}

sub mydate {

  my ($sec, $min, $hr, $day, $mon, $yr) = localtime();
  return sprintf('%02d/%02d/%4d %02d:%02d:%02d', 
		  $mon + 1, $day, $yr + 1900, $hr, $min, $sec);
}


########################################################################
# sub configure()
# Read the config file and set the appropriate values
########################################################################
sub configure {

  #unshift @$config_dirs, "/data/$evid/config";
  my $cfg  = new LoadConfig($cfile, $config_dirs, \&logscr)
                or logerr "Couldn't open config file $cfile";

  $cfg->parse( {'logfile'		=> \&logfile,
				'download_dir'	=> \&download_dir,
				'rss_url'		=> \&rss_url,
				'region'		=> \&region,
				'data_file'		=> \&data_file,
                'postcmd'		=> \&postcmd,
                'time_window'		=> \&time_window,
                'mag_cutoff'		=> \&mag_cutoff,
	       } )
    
	== 0 or logerr "Error in config file, quitting...";

  return 0;
}

#######################################################################
# Configuration subroutines
#######################################################################

sub logfile {

  $logfile = shift;
  #----------------------------------------------------------------------
  # Replace the <RSS_HOME> string with the install dir
  #----------------------------------------------------------------------
  $logfile =~ s/<RSS_HOME>/$rss_home/;
  #----------------------------------------------------------------------
  # logfile is guaranteed to be something, but can we open it?
  #----------------------------------------------------------------------
  if (!open(LOGOUT, ">> $logfile")) {
    logscr "can't open $logfile; trying /tmp/shake_rssreader.log";
    $logfile = '/tmp/shake_rssreader.log';
    if (!open(LOGOUT, ">> $logfile")) {
      logscr "can't open $logfile; will message to STDOUT";
      $logfile = 'STDOUT';
      $log = \*STDOUT;
      return "Couldn't open a logfile";
    }
    LOGOUT->autoflush(1);
    logscr "ok: logging to $logfile";
    $log = \*LOGOUT;
    return "Logging to $logfile";
  }
  LOGOUT->autoflush(1);
  $log = \*LOGOUT;
  return undef;
}

sub rss_url {
  
  my $url = shift;

  defined $url 
	or return "rss_url: bad value: $url";

  $rss_url = $url;
  return undef;
}

sub time_window {
  
  my $window = shift;

  $time_window = $window;
  return undef;
}

sub mag_cutoff {
  
  my $mag = shift;

  $mag_cutoff = $mag;
  return undef;
}

sub region {
  
  my $netid = shift;

  defined $netid 
	or return "region: bad value: $netid";

  push @regions, split(' ', $netid);
  $all_regions = 1 if (grep /all/i, @regions);
#  print join('::', @regions),", $all_regions\n";
  return undef;
}

sub download_dir {
  
  my $download = shift;
    
  defined $download 
	or return "download: argument required";

  $download =~ s/<RSS_HOME>/$rss_home/;

  #validate directory
  if (not -e "$download") {
    mkpath("$download", 0, 0755) or logerr "Couldn't create download dir";
  }

  $download_dir = $download;
  return undef;
}

sub data_file {

  my $data    = shift;

  defined $data 
	or return "data_file: argument required";
  
  if (defined $evid) {
	$data =~ s/<EVENT>/$evid/g;
  }
  push @data_files, $data;

  return undef;
}

sub postcmd {

  my $command = shift;

  defined $command 
	or return "postcmd: argument required";

  $command =~ s/<RSS_HOME>/$rss_home/;
  if (defined $evid) {
	$command =~ s/<EVENT>/$evid/g;
  }

  push @postcmds, $command;
  return undef;
}


#######################################################################
# LoadConfig Package
#######################################################################

package LoadConfig;

BEGIN {
#       @(#)LoadConfig.pm	1.7     07/15/03     TriNet

use strict;
use Carp;

#######################################################################
# LoadConfig provides an interface to reading configuration files with
# the structure:
#
#	statement : value
#
# where the first ':' splits the two strings (which may contain
# whitespace.
#
# The following functions are provided:
#
# new("filename", <ref to array of directories> [, $errfunc])
# 
#	Initializes a new LoadConfig object. Returns 'undef' on error.
#	Arguments:
#
#	"filename" is the name of the config file; the module will look
#                  for this file in the directories specified by the list
#                  and in the order that they appear, using the first
#                  instance of the file that it finds
#
#	"$errfunc" is a reference to an error reporting function which 
#	           takes a string argument ('carp' is used by default)  
#	           The error function will be passed a string with no \n 
#		   on the end, and is expected to add one if appropriate 
#		   (which it usually is).
#
# LoadConfig::parse( $func_hash_ref [, $opt_arg] )
#
#	Generic config file parser.  The argument "$func_hash_ref" is a 
#	reference to a hash of (statement => $func_ref) pairs, where 
#	'statement' is the name of the statement in the config file, and 
#	'$func_ref' is a reference to the function to call when that 
#	statement is encountered.  The 'value' part of the configuration 
#	line will be passed to the user function as its first argument; if
#	'$opt_arg' is supplied, it will be passed as the second argument,
#	otherwise 'undef' will be passed as the second argument.  These 
#	user-defined functions should return "undef" on success, and an 
#	arbitrarily complex error message on failure.  The parser will not 
#	quit on error (unless the error function supplied to "LoadConfig::new" 
#	exits when called), but will try to finish parsing the file and 
#	return the number of errors encountered.
#
#	The parser allows multi-line "value" segments that are continued 
#	by ending the line with a "&&".  Example:
#
#		count : one two     &&
#			three four
#
#	Is equivalent to:
#
#		count : one two three four
#
#	If anything other than a carriage return (except white space)
#	follows the "&&", the "&&" will be considered part of a single-
#	line "value" statement and will be passed to the statement 
#	handler as part of the argument.
#
# Custom handling of config files is achieved through the use of the
# following access methods:
#
# LoadConfig::nextsv()
#
#	Returns a two-element list consisting of the statement and value
#	of the next non-comment, non-empty line in the config file.  Returns
#	(undef, undef) on error.  The strings returned have their leading
#	and trailing whitespace stripped.
#
# LoadConfig::nextsv_raw()
#
#	Returns a two-element list consisting of the statement and value
#	of the next non-comment, non-empty line in the config file.  Returns
#	(undef, undef) on error.
#
# LoadConfig::nextline()
#
#	Returns the next non-comment, non-empty line in the config file.  
#	Returns undef on error.  The strings returned have their leading
#	and trailing whitespace stripped.
#
# LoadConfig::nextline_raw()
#
#	Returns the next non-comment, non-empty line in the config file.  
#	Returns undef on error.
#
# LoadConfig::linenum()
#
#	Returns the line number (in the config file) of the current line.
#	Note that this includes comments and blank lines.
#
# LoadConfig::more()
#
#	Returns true (1) if there are more lines in the config, otherwise
#	returns false (0)
#######################################################################

#######################################################################
# The 'self' object contains the following elements:
#
# FILE    => Config file
# PFUNCS  => Reference to a hash of user-defined functions to call, 
#            keyed by statement name (if the parse() function is used)
# EFUNC   => Reference to the error function
# CFGARR  => Array of configuration lines
# LINEARR => Line numbers to corresponding lines in CFGARR
# INDEX   => Current index
#######################################################################

sub new {

  my $self  = {};
  my $class = shift;
  my $file  = shift;
  my $aref  = shift;
  $self->{EFUNC} = shift || \&carp;

  if (not defined $file) {
    &{$self->{EFUNC}}("ERROR in LoadConfig::new: must specify config file");
    return undef;
  }
  if (!defined $aref) {
    &{$self->{EFUNC}}("ERROR in LoadConfig::new: no search path given");
    return undef;
  }
  #-----------------------------------------------------------------------
  # Look for the config file in the specified places
  #-----------------------------------------------------------------------
  foreach my $dir ( @$aref ) {
    my $path = "$dir/$file";
    if (-e "$path") {
      $self->{FILE} = $path;
      last;
    }
  }
  if (not defined $self->{FILE}) {
    &{$self->{EFUNC}}("LoadConfig::new ERROR: can't find config file "
		    . "'$file' in\n" 
		    . join(",\n", @$aref));
    return undef;
  }

  unless (open(CONFIG, $self->{FILE})) {
    &{$self->{EFUNC}}("LoadConfig::new ERROR: can't open config file "
		    . "$self->{FILE}");
    return undef;
  }
  $self->{CFGARR}  = [];
  $self->{LINEARR} = [];
  $self->{INDEX}   = -1;

  #----------------------------------------------------------------------
  # Read the config file; we used to do this:
  #
  #  my @cfgarr = grep {!/^#/ and !/^\n/} <CONFIG>;
  #
  # But we wanted to count lines, so now we use the less clever loop
  # below
  #----------------------------------------------------------------------
  while (<CONFIG>) {
    next if (/^#/ or /^\n/);
    push @{$self->{CFGARR}}, $_;
    push @{$self->{LINEARR}}, $.;
  }
  close CONFIG;
  chomp @{$self->{CFGARR}};

  return bless $self, $class;
}

###########################################################################
# Generic parsing function.  See documentation above.
###########################################################################
sub parse {

  my $self      = shift;
  my $erf       = $self->{EFUNC};
  my $configerr = 0;

  if (!defined ($self->{PFUNCS} = shift)) {
    &$erf("ERROR in LoadConfig::parse: must specify function hash");
    return undef;
  }
  my $opt_arg   = shift || undef;	# kind of redundant, but explicit

  while ($self->more) {
    my ($statement, $value) = $self->nextsv;
    my $lineno = $self->linenum;
    #----------------------------------------------------------------------
    # Check for a valid line in the config file -- we should really quit
    # if this test fails, forcing a properly written config file, but
    # we don't want to kill a functioning program just because of a 
    # reconfig, so we do the best we can and report errors at the end.
    #----------------------------------------------------------------------
    if (!defined $statement || !defined $value) {
      &$erf("unusable line (line $lineno) in config file:\n\t"
	  . "line must be of the 'statement : value' form");
      $configerr++;
      next;
    }

    #----------------------------------------------------------------------
    # Special handling for multi-line statements
    #----------------------------------------------------------------------
    while ($value =~ /&&$/) {
      $value =~ s/\s&&$//;
      if (!$self->more) {
        &$erf("end of file reached on continued line");
	$configerr++;
	last;
      }
      #--------------------------------------------------------------------
      # Basically, we just glue what follows onto the line
      #--------------------------------------------------------------------
      $value .= " " . $self->nextline;
    }

    #----------------------------------------------------------------------
    # Get the handler function that corresponds to the statement
    #----------------------------------------------------------------------
    my $fref = $self->{PFUNCS}{$statement} || $self->{PFUNCS}{'DEFAULT'};
    if (!defined $fref) {
      &$erf("unknown statement '$statement' on line $lineno of config file\n");
      $configerr++;
      next;
    }

    #----------------------------------------------------------------------
    # Call the appropriate handler
    #----------------------------------------------------------------------
    if (defined (my $errmsg = &$fref($value, $opt_arg))) {
      #-----------------------------------------------------------------------
      # Strip any trailing \n from the errmsg (because the error function
      # is presumed to add one); strip multiple \n's and stick a tab in
      # front of each line
      #-----------------------------------------------------------------------
      $errmsg =~ s/\n+$//;
      $errmsg =~ s/\n+/\n/g;
      $errmsg =~ s/\n/\n\t/g;
      &$erf("CONFIG ERROR: '$statement' statement at line $lineno in "
	  . "$self->{FILE}:\n"
	  . "\t$errmsg");
      $configerr++; 
    }
  }
  return $configerr;
}

#######################################################################
# Returns the statement/value pair of the next line in the config file
# -- no whitespace stripping
#######################################################################
sub nextsv_raw {

  my $self = shift;

  if (!$self->more) {
    &{$self->{EFUNC}}("LoadConfig::nextsv_raw ERROR: no more lines");
    return (undef, undef);
  }
  return split(":", $self->{CFGARR}[ ++$self->{INDEX} ], 2);
}

#######################################################################
# Returns the statement/value pair of the next line in the config file
# with whitespace stripped
#######################################################################
sub nextsv {

  my $self    = shift;
  my ($s, $v) = $self->nextsv_raw();

  return (undef, undef) if (!defined $s and !defined $v);

  if (!defined $s or !defined $v) {
    &{$self->{EFUNC}}("LoadConfig::nextsv ERROR: bad line in input");
    return (undef, undef);
  }

  #----------------------------------------------------------------------
  # Strip whitespace before returning
  #----------------------------------------------------------------------
  chomp $s;
  chomp $v;
  return ( $s =~ /^\s*(.+?)\s*$/, $v =~ /^\s*(.+?)\s*$/ );
}

#######################################################################
# Returns the next line in the config file -- no whitespace stripping 
#######################################################################
sub nextline_raw {

  my $self = shift;

  if (!$self->more) {
    &{$self->{EFUNC}}("LoadConfig::nextline_raw ERROR: no more lines");
    return undef;
  }
  return $self->{CFGARR}[ ++$self->{INDEX} ];
}

#######################################################################
# Returns the next line in the config file
#######################################################################
sub nextline {

  my $self = shift;
  my $l    = $self->nextline_raw();

  return undef if !defined $l;

  chomp $l;
  return ($l =~ /^\s*(.+?)\s*$/)[0];
}

#######################################################################
# Returns the line number (in the config file) of the current line
#######################################################################
sub linenum {

  my $self = shift;

  return $self->{LINEARR}[$self->{INDEX}];
}

#######################################################################
# Returns true (1) if there are more lines in the config, otherwise
# returns false (0)
#######################################################################
sub more {

  my $self = shift;

  return 1 if ($self->{INDEX} + 1 < @{$self->{CFGARR}});
  return 0;
}
}

