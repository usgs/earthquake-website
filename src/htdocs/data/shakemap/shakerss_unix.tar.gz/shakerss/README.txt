README.TXT for shake_rssreader


* Typical usage for Windows users

1. Unzip the file into a directory, e.g., "c:\shakerss."  
2. Edit the file "shake_rssreader.conf" to specify regions, ShakeMap products, and post-commands.
3. Double-click to run the executable "shake_rssreader.exe."  A DOS console window should appear with download status.  The window will be closed when the download is complete.
4. To run this script frequently, add it to "Start->Settings->Control Panel->Schedule Tasks->Add Scheduled Task."  

Note: The source scripts in Perl are available in the "src" directory.  To run the Perl scripts, make sure that ActivePerl is installed, which can be downloaded at http://aspn.activestate.com/ASPN/Downloads/ActivePerl/


* Typical usage for Mac/UNIX users

1. Uncompress the tar-ball file into a directory, e.g., "~user/shakerss."
	tar zxvf shake_rssreader.tar.gz 
2. [OPTIONAL] If installed already, or install perl module LWP::Simple (instructions in shake_rssread.pl)
   AND in shake_rssreader.pl uncomment out line: "# LWP::Simple" and comment out line "require "SimpleGet.pl"
3. Edit the file "shake_rssreader.conf" to specify regions, ShakeMap products, and post-commands.
4. Run the script "shake_rssreader.pl" to download recent ShakeMaps manually.
5. To run this script as a cron job, try the following example

	Crontab, running RSS reader every 5 minutes:
*/5 * * * * cd /home/user/shakerss/; perl shake_rssreader.pl  &

